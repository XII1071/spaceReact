import {
  require_react
} from "./chunk-6JKWCWVM.js";
export default require_react();
