export default function CopyMe() {
  return (
    <section className="mt-4">
      <h2 className="font-bold text-5xl text-center">CopyMe</h2>
      <div className="mt-4"></div>
    </section>
  )
}
