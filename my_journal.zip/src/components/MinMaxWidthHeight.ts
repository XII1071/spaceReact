export type MinMaxWidthHeight = {
  minWidth?: string
  maxWidth?: string
  minHeight?: string
  maxHeight?: string
}
