import {atom} from 'jotai'

export const imageNameAtom = atom('')
